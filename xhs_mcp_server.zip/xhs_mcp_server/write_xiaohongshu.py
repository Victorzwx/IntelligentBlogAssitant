# 小红书的自动发稿
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
import time
import json
import os
import sys
import subprocess
import platform
import logging

# 配置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('XiaohongshuPoster')

class XiaohongshuPoster:
    def __init__(self, path=os.path.dirname(os.path.abspath(__file__)), headless=False):
        # 创建 Chrome 选项对象
        chrome_options = Options()
        # 如果 headless 为 True，则设置为无头模式
        if headless:
            chrome_options.add_argument('--headless=new')  # 使用新的无头模式
            chrome_options.add_argument('--disable-gpu')  # 禁用 GPU 加速
            chrome_options.add_argument('--window-size=1920,1080')  # 设置窗口大小
            chrome_options.add_argument('--no-sandbox')  # 禁用沙盒模式
            chrome_options.add_argument('--disable-dev-shm-usage')  # 禁用 /dev/shm 使用
        
        # 添加更多选项以提高稳定性
        chrome_options.add_argument('--disable-extensions')  # 禁用扩展
        chrome_options.add_argument('--disable-popup-blocking')  # 禁用弹出窗口阻止
        chrome_options.add_argument('--disable-blink-features=AutomationControlled')  # 禁用自动化控制检测
        chrome_options.add_experimental_option('excludeSwitches', ['enable-automation'])  # 排除自动化开关
        chrome_options.add_experimental_option('useAutomationExtension', False)  # 不使用自动化扩展
        
        # 尝试多种方式初始化 Chrome 驱动
        self.driver = self._initialize_chrome_driver(chrome_options)
        
        # 设置等待时间为 10 秒
        self.wait = WebDriverWait(self.driver, 10)
        # 保存路径
        self.path = path
        # 设置 cookies 文件路径 - 修改为直接使用xiaohongshu_cookies.json
        self.cookies_file = os.path.join(os.path.dirname(__file__), "xiaohongshu_cookies.json")
        # 确保目录存在
        os.makedirs(os.path.dirname(self.cookies_file), exist_ok=True)
        # 加载 cookies
        self._load_cookies()

    def _initialize_chrome_driver(self, chrome_options):
        """尝试多种方式初始化 Chrome 驱动"""
        methods = [
            self._init_with_default,
            self._init_with_service,
            self._init_with_executable_path,
            self._init_with_system_chrome,
            self._init_with_webdriver_manager
        ]
        
        for method in methods:
            try:
                logger.info(f"尝试使用方法 {method.__name__} 初始化 Chrome 驱动")
                driver = method(chrome_options)
                if driver:
                    logger.info(f"使用方法 {method.__name__} 成功初始化 Chrome 驱动")
                    return driver
            except Exception as e:
                logger.error(f"使用方法 {method.__name__} 初始化 Chrome 驱动失败: {str(e)}")
                continue
        
        # 如果所有方法都失败，抛出异常
        raise Exception("无法初始化 Chrome 驱动，请确保已安装 Chrome 浏览器并将 ChromeDriver 添加到系统路径中")

    def _init_with_default(self, chrome_options):
        """使用默认方式初始化 Chrome 驱动"""
        return webdriver.Chrome(options=chrome_options)
    
    def _init_with_service(self, chrome_options):
        """使用 Service 对象初始化 Chrome 驱动"""
        service = Service()
        return webdriver.Chrome(service=service, options=chrome_options)
    
    def _init_with_executable_path(self, chrome_options):
        """使用可执行路径初始化 Chrome 驱动"""
        # 尝试在常见位置查找 chromedriver
        possible_paths = [
            "chromedriver.exe",  # 当前目录
            os.path.join(os.path.dirname(__file__), "chromedriver.exe"),  # 包目录
            os.path.join(os.path.expanduser("~"), "chromedriver.exe"),  # 用户目录
            r"C:\Program Files\Google\Chrome\Application\chromedriver.exe",
            r"C:\Program Files (x86)\Google\Chrome\Application\chromedriver.exe"
        ]
        
        for path in possible_paths:
            if os.path.exists(path):
                service = Service(executable_path=path)
                return webdriver.Chrome(service=service, options=chrome_options)
        
        # 如果找不到，尝试使用 PATH 中的 chromedriver
        return None
    
    def _init_with_system_chrome(self, chrome_options):
        """尝试使用系统 Chrome 浏览器路径初始化 Chrome 驱动"""
        # 获取 Chrome 浏览器路径
        chrome_path = self._get_chrome_path()
        if chrome_path:
            chrome_options.binary_location = chrome_path
            return webdriver.Chrome(options=chrome_options)
        return None
    
    def _init_with_webdriver_manager(self, chrome_options):
        """使用 webdriver_manager 初始化 Chrome 驱动"""
        try:
            from webdriver_manager.chrome import ChromeDriverManager
            service = Service(ChromeDriverManager().install())
            return webdriver.Chrome(service=service, options=chrome_options)
        except ImportError:
            # 如果没有安装 webdriver_manager，尝试安装
            subprocess.check_call([sys.executable, "-m", "pip", "install", "webdriver-manager"])
            from webdriver_manager.chrome import ChromeDriverManager
            service = Service(ChromeDriverManager().install())
            return webdriver.Chrome(service=service, options=chrome_options)
    
    def _get_chrome_path(self):
        """获取系统 Chrome 浏览器路径"""
        system = platform.system()
        if system == "Windows":
            # Windows 系统下的常见 Chrome 路径
            possible_paths = [
                r"C:\Program Files\Google\Chrome\Application\chrome.exe",
                r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
                os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe")
            ]
            for path in possible_paths:
                if os.path.exists(path):
                    return path
        elif system == "Darwin":  # macOS
            return "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
        elif system == "Linux":
            # 尝试使用 which 命令查找 Chrome
            try:
                return subprocess.check_output(["which", "google-chrome"]).decode().strip()
            except:
                return None
        return None

    def _load_cookies(self):
        """从文件加载cookies"""
        if os.path.exists(self.cookies_file):
            try:
                # 打开 cookies 文件
                with open(self.cookies_file, 'r') as f:
                    # 加载 cookies
                    cookies = json.load(f)
                    # 访问小红书创作者中心
                    self.driver.get("https://creator.xiaohongshu.com")
                    # 添加 cookies
                    for cookie in cookies:
                        self.driver.add_cookie(cookie)
                # 返回 True 表示成功加载 cookies
                return True
            except Exception as e:
                # 打印错误信息
                print(f"加载 cookies 失败: {e}")
                # 返回 False 表示加载 cookies 失败
                return False
        # 如果 cookies 文件不存在，返回 False
        return False

    def _save_cookies(self):
        """保存cookies到文件"""
        # 获取当前的 cookies
        cookies = self.driver.get_cookies()
        # 确保目录存在
        os.makedirs(os.path.dirname(self.cookies_file), exist_ok=True)
        # 将 cookies 保存到文件
        with open(self.cookies_file, 'w') as f:
            json.dump(cookies, f)

    def login(self):
        """登录小红书"""
        # 访问小红书创作者中心登录页面
        self.driver.get("https://creator.xiaohongshu.com/login")
        # 加载 cookies
        cookies_loaded = self._load_cookies()
        # 刷新页面
        self.driver.refresh()
        # 等待 1.5 秒
        time.sleep(1.5)
        
        # 检查是否已经登录
        if self.driver.current_url != "https://creator.xiaohongshu.com/login":
            print("使用cookies登录成功")
            # 保存 cookies
            self._save_cookies()
            # 等待 2 秒
            time.sleep(2)
            # 登录成功，返回
            return True
        else:
            # 清理无效的cookies
            self.driver.delete_all_cookies()
            print("无效的cookies，已清理")

        # 如果cookies登录失败，则进行手动登录
        self.driver.get("https://creator.xiaohongshu.com/login")

        # 等待登录页面加载完成
        time.sleep(5)

        # 输入验证码
        verification_code = input("请输入验证码: ")
        # 定位验证码输入框
        code_input = self.wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, "input[placeholder='验证码']")))
        # 清空输入框
        code_input.clear()
        # 输入验证码
        code_input.send_keys(verification_code)

        # 点击登录按钮
        login_button = self.wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, ".beer-login-btn")))
        login_button.click()

        # 等待登录成功
        time.sleep(3)
        # 保存cookies
        self._save_cookies()
        
        # 返回登录成功
        return True

    def post_article(self, title, content, images=None):
        """发布文章
        Args:
            title: 文章标题
            content: 文章内容
            images: 图片路径列表
        """
        # 点击发布按钮
        publish_btn = self.wait.until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, ".btn.el-tooltip__trigger.el-tooltip__trigger")))
        publish_btn.click()

        # 切换到上传图文
        time.sleep(2)
        # 查找所有标签
        tabs = self.driver.find_elements(By.CSS_SELECTOR, ".creator-tab")
        # 如果有多个标签，点击第二个（图文）
        if len(tabs) > 1:
            tabs[1].click()
        time.sleep(2)

        # 上传图片
        if images:
            # 查找上传输入框
            upload_input = self.driver.find_element(By.CSS_SELECTOR, ".upload-input")
            # 将所有图片路径用\n连接成一个字符串一次性上传
            upload_input.send_keys('\n'.join(images))
            time.sleep(1)
        time.sleep(2)
        
        # 限制标题长度为20字
        title = title[:20]
        # 输入标题
        title_input = self.wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, ".d-text")))
        title_input.send_keys(title)

        # 输出内容到控制台
        print(content)
        # 输入内容
        content_input = self.wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, ".ql-editor")))
        content_input.send_keys(content)
        
        # 等待2秒
        time.sleep(2)
        # 点击发布按钮
        submit_btn = self.driver.find_element(By.CSS_SELECTOR, ".publishBtn")
        submit_btn.click()
        
        # 输出发布成功信息
        print('发布成功')
        # 等待8秒
        time.sleep(8)
        
        # 返回发布成功
        return True

    def post_video_article(self, title, content, videos=None):
        """发布视频文章
        Args:
            title: 文章标题
            content: 文章内容
            videos: 视频路径列表
        """
        # 等待3秒
        time.sleep(3)
        # 点击发布按钮
        publish_btn = self.wait.until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, ".btn.el-tooltip__trigger.el-tooltip__trigger")))
        publish_btn.click()

        # 等待3秒
        time.sleep(3)

        # 上传视频
        if videos:
            # 查找上传输入框
            upload_input = self.driver.find_element(By.CSS_SELECTOR, ".upload-input")
            # 将所有视频路径用\n连接成一个字符串一次性上传
            upload_input.send_keys('\n'.join(videos))
            time.sleep(1)
        time.sleep(3)
        
        # 输入标题
        title_input = self.wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, ".d-text")))
        title_input.send_keys(title)

        # 输出内容到控制台
        print(content)
        # 输入内容
        content_input = self.wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, ".ql-editor")))
        content_input.send_keys(content)
        
        # 等待6秒（视频上传需要更长时间）
        time.sleep(6)
        # 点击发布按钮
        submit_btn = self.driver.find_element(By.CSS_SELECTOR, ".publishBtn")
        submit_btn.click()
        
        # 输出发布成功信息
        print('发布成功')
        # 等待3秒
        time.sleep(3)
        
        # 返回发布成功
        return True

    def close(self):
        """关闭浏览器"""
        # 关闭浏览器
        self.driver.quit()

