import os
import time
import requests
import tempfile
import sys
import logging
import traceback

from mcp.server import FastMCP
from mcp.types import TextContent

from .write_xiaohongshu import XiaohongshuPoster

# 配置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('xhs_mcp_server')

# 初始化 FastMCP 实例，名称为 "xhs"
mcp = FastMCP("xhs")
# 直接使用包内的data目录
path = os.getenv("json_path", os.path.join(os.path.dirname(__file__), "data"))
# 确保 data 目录存在
os.makedirs(path, exist_ok=True)

def login():
    """登录小红书并保存 cookies"""
    try:
        logger.info("开始登录小红书")
        # 创建 XiaohongshuPoster 实例 - 不再需要传递path参数，因为cookie路径已固定
        poster = XiaohongshuPoster()
        # 登录小红书
        poster.login()
        # 等待 1 秒
        time.sleep(1)
        # 关闭浏览器
        poster.close()
        logger.info("登录小红书成功")
        return True
    except Exception as e:
        logger.error(f"登录小红书失败: {str(e)}")
        traceback.print_exc()
        return False

@mcp.tool()
def create_note(title: str, content: str, images: list) -> list[TextContent]:
    """Create a note (post) to xiaohongshu (rednote) with title, description, and images

    Args:
        title: the title of the note (post), which should not exceed 20 words
        content: the description of the note (post).
        images: the list of image paths or URLs to be included in the note (post)
    """
    logger.info(f"开始创建小红书笔记: 标题={title}, 图片数量={len(images)}")

    # 验证图片路径
    valid_images = []
    for img_path in images:
            # 检查本地图片是否存在
            if os.path.exists(img_path):
                logger.info(f"使用本地图片: {img_path}")
                valid_images.append(img_path)
            else:
                logger.error(f"图片路径不存在: {img_path}")
                return [TextContent(type="text", text=f"error: 图片路径不存在 - {img_path}")]

    if not valid_images:
        logger.error("没有有效的图片")
        return [TextContent(type="text", text="error: 没有有效的图片")]

    try:
        # 创建 XiaohongshuPoster 实例，启用无头模式 - 不再需要传递path参数
        logger.info("初始化 XiaohongshuPoster")
        poster = XiaohongshuPoster(headless=False)
        
        # 使用 cookies 登录
        logger.info("使用 cookies 登录")
        login_success = poster.login()
        
        if not login_success:
            logger.error("登录失败")
            return [TextContent(type="text", text="error: 登录失败，请先运行 login 命令设置 cookies")]
        
        # 发布文章
        logger.info("开始发布文章")
        poster.post_article(title, content, valid_images)
        
        # 关闭浏览器
        logger.info("关闭浏览器")
        poster.close()
        
        # 设置结果为成功
        logger.info("发布成功")
        res = "success"
    except Exception as e:
        # 如果发生异常，设置结果为错误信息
        logger.error(f"发布失败: {str(e)}")
        traceback.print_exc()
        res = f"error: {str(e)}"

    # 返回结果
    return [TextContent(type="text", text=res)]


@mcp.tool()
def create_video_note(title: str, content: str, videos: list) -> list[TextContent]:
    """Create a note (post) to xiaohongshu (rednote) with title, description, and videos

    Args:
        title: the title of the note (post), which should not exceed 20 words
        content: the description of the note (post).
        videos: the list of video paths or URLs to be included in the note (post)
    """
    # 创建 XiaohongshuPoster 实例，启用无头模式 - 不再需要传递path参数
    poster = XiaohongshuPoster(headless=False)
    # 使用 cookies 登录
    poster.login()
    # 初始化结果变量
    res = ""
    try:
        # 下载网络视频到本地缓存地址
        local_videos = []
        # 遍历所有视频
        for video in videos:

                # 如果是本地视频，直接添加
                local_videos.append(video)

        # 发布视频文章
        poster.post_video_article(title, content, local_videos)
        # 关闭浏览器
        poster.close()
        # 设置结果为成功
        res = "success"
    except Exception as e:
        # 如果发生异常，设置结果为错误信息
        res = "error:" + str(e)

    # 返回结果
    return [TextContent(type="text", text=res)]



def main():
    """主函数，运行 MCP 服务器"""
    # 运行 MCP 服务器
    mcp.run()

def test_create_note():
    """测试 create_note 函数"""
    # 测试标题
    title = "测试帖子"
    # 测试内容
    content = "这是一个测试帖子，用于测试 create_note 函数。"
    # 测试图片，使用示例图片 URL
    images = ["https://example.com/test.jpg"]
    # 调用 create_note 函数
    result = create_note(title, content, images)
    # 打印结果
    print(result)
    # 返回结果
    return result

if __name__ == "__main__":
    # 如果直接运行此脚本，则运行主函数
    main()