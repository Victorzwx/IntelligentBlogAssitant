import os
import sys
import subprocess
import platform
import requests
import time

def main():
    """设置环境，安装必要的依赖"""
    print("开始设置环境...")
    
    # 安装依赖
    requirements_path = os.path.join(os.path.dirname(__file__), "requirements.txt")
    if os.path.exists(requirements_path):
        print(f"安装依赖: {requirements_path}")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", requirements_path])
    else:
        print("安装基本依赖...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "selenium", "requests", "mcp", "webdriver-manager"])
    
    # 检查远程 Selenium 服务器
    selenium_remote_url = os.getenv("SELENIUM_REMOTE_URL")
    if selenium_remote_url:
        print(f"检查远程 Selenium 服务器: {selenium_remote_url}")
        try:
            # 尝试连接到远程 Selenium 服务器
            response = requests.get(f"{selenium_remote_url}/status", timeout=5)
            if response.status_code == 200:
                print("远程 Selenium 服务器可用")
            else:
                print(f"远程 Selenium 服务器返回状态码: {response.status_code}")
        except Exception as e:
            print(f"无法连接到远程 Selenium 服务器: {str(e)}")
            print("请确保 Selenium 服务器正在运行，并且可以从此机器访问")
    else:
        # 尝试安装 ChromeDriver
        try:
            print("安装 ChromeDriver...")
            from webdriver_manager.chrome import ChromeDriverManager
            driver_path = ChromeDriverManager().install()
            print(f"ChromeDriver 已安装到: {driver_path}")
        except Exception as e:
            print(f"安装 ChromeDriver 失败: {str(e)}")
            print("请手动下载 ChromeDriver 并将其添加到系统路径中")
            print("下载地址: https://chromedriver.chromium.org/downloads")
    
    print("环境设置完成")

if __name__ == "__main__":
    main()