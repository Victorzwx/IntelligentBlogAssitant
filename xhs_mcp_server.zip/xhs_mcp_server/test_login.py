import os
import sys
import time
import logging
from write_xiaohongshu import XiaohongshuPoster

# 配置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('test_login')

def test_login():
    """测试小红书登录功能"""
    try:
        logger.info("开始测试登录功能")
        
        # 获取当前目录作为数据存储路径
        path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
        # 确保目录存在
        os.makedirs(path, exist_ok=True)
        
        # 创建 XiaohongshuPoster 实例
        logger.info(f"使用路径: {path}")
        poster = XiaohongshuPoster(path)
        
        # 尝试登录
        logger.info("尝试登录小红书")
        login_success = poster.login()
        
        # 检查登录结果
        if login_success:
            logger.info("登录成功")
            # 检查 cookies 文件是否存在
            cookies_file = os.path.join(path, "xiaohongshu_cookies.json")
            if os.path.exists(cookies_file):
                logger.info(f"Cookies 文件已保存: {cookies_file}")
            else:
                logger.error(f"Cookies 文件未保存: {cookies_file}")
        else:
            logger.error("登录失败")
        
        # 等待 2 秒
        time.sleep(2)
        
        # 关闭浏览器
        logger.info("关闭浏览器")
        poster.close()
        
        return login_success
    except Exception as e:
        logger.error(f"测试登录功能时发生错误: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

def main():
    """主函数"""
    # 运行测试
    result = test_login()
    # 打印结果
    if result:
        print("测试通过: 登录功能正常")
    else:
        print("测试失败: 登录功能异常")

if __name__ == "__main__":
    main()