from . import login

if __name__ == "__main__":
    login()